# Terrain provenance

{
  "original_provenance_sha256": "74cea3292f9a1255a88be5429959fefed70327b141fe223a328466f3b9e7899f",
  "original_fixture_revision": 2,
  "converter_source_commit": "151905b4b82e1beb131fc2ac069eaace0b840817",
  "terrain_bake_command": "flightsim-tilegen --input derived/liechtenstein-ellipsoidal.tif --output tiles --bounds 9.316406251,46.933593751,9.843749999,47.460937499 --min-level 10 --max-level 13 --grid-size 65 --min-coverage 1",
  "sources": [
    {
      "dataset": "Copernicus GLO-90 public N47E009",
      "url": "https://copernicus-dem-90m.s3.amazonaws.com/Copernicus_DSM_COG_30_N47_00_E009_00_DEM/Copernicus_DSM_30_N47_00_E009_00.xml",
      "bytes": 44690,
      "sha256": "0ca804a700fa9fb2d16f8451b10ab782e14554b5af1f475d6e026aea2474a8ec",
      "retrieved_session_date_utc": "2026-10-02"
    },
    {
      "dataset": "Copernicus GLO-90 public N47E009",
      "url": "https://copernicus-dem-90m.s3.amazonaws.com/Copernicus_DSM_COG_30_N47_00_E009_00_DEM/Copernicus_DSM_COG_30_N47_00_E009_00_DEM.tif",
      "bytes": 4879071,
      "sha256": "51f5f20d1a5c8351dd8f8a18e8ae376bf93253c300d95a6e0b54c9fe75640a4c",
      "retrieved_session_date_utc": "2026-10-02"
    },
    {
      "dataset": "Copernicus GLO-90 public N46E009",
      "url": "https://copernicus-dem-90m.s3.amazonaws.com/Copernicus_DSM_COG_30_N46_00_E009_00_DEM/Copernicus_DSM_30_N46_00_E009_00.xml",
      "bytes": 44690,
      "sha256": "090dea9689d3986d5d6ea526ad598b0246686a5889786bd4cf729e49683234be",
      "retrieved_session_date_utc": "2026-10-02"
    },
    {
      "dataset": "Copernicus GLO-90 public N46E009",
      "url": "https://copernicus-dem-90m.s3.amazonaws.com/Copernicus_DSM_COG_30_N46_00_E009_00_DEM/Copernicus_DSM_COG_30_N46_00_E009_00_DEM.tif",
      "bytes": 5225729,
      "sha256": "6860c0b93a271f3b702a4a16aa885ba19c4907e808c56f94a620c6a657aa5f18",
      "retrieved_session_date_utc": "2026-10-02"
    },
    {
      "dataset": "NOAA ETOPO2022 v1 EGM2008 geoid",
      "url": "https://www.ngdc.noaa.gov/thredds/dodsC/global/ETOPO2022/60s/60s_geoid_netcdf/ETOPO_2022_v1_60s_N90W180_geoid.nc.dods?z[0:10:10799][0:10:21599]",
      "bytes": 9357389,
      "sha256": "0bdb4e88ed0d65c08052d2ae62bd981353333859c24a80dfd57c088efe45a600",
      "use": "Previously acquired public source reused locally after hash validation; matching 10arcminute EGM2008 bilinear correction",
      "licence": "NOAA public domain"
    }
  ],
  "terrain": {
    "schema": "flightsim-liechtenstein-regional-dem-v1",
    "status": "INDEPENDENT_SOURCE_AND_TILE_VERIFICATION_PASS",
    "requested_bbox_wsen_deg": [
      9.4,
      47.03,
      9.68,
      47.31
    ],
    "focus_bbox_wsen_deg": [
      9.4,
      47.03,
      9.68,
      47.31
    ],
    "bake_bbox_inward_wsen_deg": [
      9.316406251,
      46.933593751,
      9.843749999,
      47.460937499
    ],
    "complete_subtree_root_ids": [
      [
        10,
        1077,
        242
      ],
      [
        10,
        1078,
        242
      ],
      [
        10,
        1079,
        242
      ],
      [
        10,
        1077,
        243
      ],
      [
        10,
        1078,
        243
      ],
      [
        10,
        1079,
        243
      ],
      [
        10,
        1077,
        244
      ],
      [
        10,
        1078,
        244
      ],
      [
        10,
        1079,
        244
      ]
    ],
    "coverage_rule": "All four primary children recursively present through level13 for each of nine level10 roots; focus area does not truncate sibling families",
    "full_runtime_bbox_wsen_deg": [
      9.31640625,
      46.93359375,
      9.84375,
      47.4609375
    ],
    "levels": [
      10,
      11,
      12,
      13
    ],
    "grid_size": 65,
    "tile_count": 765,
    "native_shape": [
      2400,
      1200
    ],
    "source_tile_shapes": [
      [
        1200,
        1200
      ],
      [
        1200,
        1200
      ]
    ],
    "mosaic_source_order_north_to_south": [
      "N47E009",
      "N46E009"
    ],
    "source_nodata_policy": "Both finite PixelIsPoint sources validated; no fill, padding or sea-level substitution",
    "native_post_registration": "PixelIsPoint; NW48N9E,3arcsecond step, shared east/south row omitted by provider",
    "source_is_dsm": true,
    "horizontal_datum": "WGS84-G1150 / EPSG4326",
    "source_vertical_datum": "EGM2008 orthometric metres / EPSG3855 from source XML, absent in GeoKeys",
    "normalization": {
      "equation": "h=H+N",
      "source_geoid": "NOAA ETOPO2022v1 EGM2008 geoid, point-decimated stride10",
      "source_geoid_sha256": "0bdb4e88ed0d65c08052d2ae62bd981353333859c24a80dfd57c088efe45a600",
      "geoid_full_array_sha256": "d7dc76e9a96a42e0de9668665f4b7c9ce66196131c594139d32266b8c64ef193",
      "interpolation": "Bilinear10arcminute matching EGM2008 at every native DEM post, float64 sum then float32 h before runtime resampling",
      "H_range_m": [
        396.84979248046875,
        2932.1357421875
      ],
      "N_range_m": [
        47.00348243713381,
        50.012796969795275
      ],
      "h_range_m": [
        443.9100036621094,
        2981.15185546875
      ],
      "h_float32_rounding_max_m": 0.00012207031247157829,
      "crop_rows": [
        644,
        1284
      ],
      "crop_columns": [
        377,
        1017
      ],
      "crop_shape": [
        640,
        640
      ],
      "crop_nw_lat_lon": [
        47.46333333333333,
        9.314166666666667
      ],
      "crop_se_lat_lon": [
        46.93083333333333,
        9.846666666666668
      ],
      "normalized_tiff": "derived/liechtenstein-ellipsoidal.tif",
      "normalized_tiff_sha256": "d96af3a2c1bd6afe0e3be283ba2f778e1540857f0314d6c1b8b88f138e83949e"
    },
    "limitations": [
      "Regional Liechtenstein vicinity only; global fallback remains outside supplied tiles",
      "GLO90 is a reflective DSM including structures/vegetation, not bare-earth terrain or surveyed airport data",
      "Native3arcsecond posts;65point runtime tiles interpolate, not new measured detail",
      "Matching10arcminute EGM2008 geoid has unquantified vertical precision",
      "OSM geometry is independently sourced; default9m building extrusions are display estimates",
      "No satellite surface imagery or photogrammetry",
      "Scenery and terrain are independently licensed, separate from code and commercial allowlist"
    ],
    "ground_samples": [
      {
        "name": "Schaan",
        "lat_lon_deg": [
          47.165,
          9.51
        ],
        "primary_level": 13,
        "ellipsoidal_ground_m": 506.80396280613536
      },
      {
        "name": "Vaduz",
        "lat_lon_deg": [
          47.141,
          9.522
        ],
        "primary_level": 13,
        "ellipsoidal_ground_m": 509.4971750582855
      },
      {
        "name": "Vaduz QA view",
        "lat_lon_deg": [
          47.127,
          9.529
        ],
        "primary_level": 13,
        "ellipsoidal_ground_m": 643.3757238327696
      },
      {
        "name": "previously parent-pinned QA point",
        "lat_lon_deg": [
          47.0959673741,
          9.5665614863
        ],
        "primary_level": 13,
        "ellipsoidal_ground_m": 1952.073939915389
      },
      {
        "name": "Balzers",
        "lat_lon_deg": [
          47.068,
          9.501
        ],
        "primary_level": 13,
        "ellipsoidal_ground_m": 522.6750371563236
      },
      {
        "name": "southern scenery",
        "lat_lon_deg": [
          47.035,
          9.55
        ],
        "primary_level": 13,
        "ellipsoidal_ground_m": 1149.4183872850717
      },
      {
        "name": "southern ancestor",
        "lat_lon_deg": [
          46.95,
          9.55
        ],
        "primary_level": 13,
        "ellipsoidal_ground_m": 571.9038233036719
      },
      {
        "name": "Buchs",
        "lat_lon_deg": [
          47.166,
          9.47
        ],
        "primary_level": 13,
        "ellipsoidal_ground_m": 500.10433801615295
      },
      {
        "name": "east hill",
        "lat_lon_deg": [
          47.165,
          9.59
        ],
        "primary_level": 13,
        "ellipsoidal_ground_m": 1001.6789439095344
      }
    ]
  },
  "verification": {
    "status": "PASS",
    "tiles": 765,
    "native_posts_compared_to_original_sources": 409600,
    "native_posts_by_source": {
      "N47E009": 355840,
      "N46E009": 53760
    },
    "source_mosaic_47_degree_join_verified": true,
    "every_native_geoid_correction_independently_verified": true,
    "ancestor_chain_complete": true,
    "complete_four_child_families": 189,
    "complete_root_subtrees": 9,
    "samples_compared": 3232125,
    "same_level_neighbor_edges_checked": 1440,
    "counts_by_level": {
      "10": 9,
      "11": 36,
      "12": 144,
      "13": 576
    },
    "maximum_source_delta_m": 0.017578125,
    "ground_samples": [
      {
        "name": "Schaan",
        "lat_lon_deg": [
          47.165,
          9.51
        ],
        "primary_level": 13,
        "ellipsoidal_ground_m": 506.80396280613536
      },
      {
        "name": "Vaduz",
        "lat_lon_deg": [
          47.141,
          9.522
        ],
        "primary_level": 13,
        "ellipsoidal_ground_m": 509.4971750582855
      },
      {
        "name": "Vaduz QA view",
        "lat_lon_deg": [
          47.127,
          9.529
        ],
        "primary_level": 13,
        "ellipsoidal_ground_m": 643.3757238327696
      },
      {
        "name": "previously parent-pinned QA point",
        "lat_lon_deg": [
          47.0959673741,
          9.5665614863
        ],
        "primary_level": 13,
        "ellipsoidal_ground_m": 1952.073939915389
      },
      {
        "name": "Balzers",
        "lat_lon_deg": [
          47.068,
          9.501
        ],
        "primary_level": 13,
        "ellipsoidal_ground_m": 522.6750371563236
      },
      {
        "name": "southern scenery",
        "lat_lon_deg": [
          47.035,
          9.55
        ],
        "primary_level": 13,
        "ellipsoidal_ground_m": 1149.4183872850717
      },
      {
        "name": "southern ancestor",
        "lat_lon_deg": [
          46.95,
          9.55
        ],
        "primary_level": 13,
        "ellipsoidal_ground_m": 571.9038233036719
      },
      {
        "name": "Buchs",
        "lat_lon_deg": [
          47.166,
          9.47
        ],
        "primary_level": 13,
        "ellipsoidal_ground_m": 500.10433801615295
      },
      {
        "name": "east hill",
        "lat_lon_deg": [
          47.165,
          9.59
        ],
        "primary_level": 13,
        "ellipsoidal_ground_m": 1001.6789439095344
      }
    ]
  },
  "original_license_pdf_sha256": "bb4a01dcd7f61acefa81c9ccd76af975e12096158169acf0d7b5c44c26c8701f",
  "scope": "Exact original765 DEM bytes repackaged; no OSM geometry, no executable, no new source/rights assertion."
}

License text normalization: pdftotext -layout extracts the complete original PDF; form-feed page separators are normalized to blank lines. Original PDF SHA-256 is retained above. No license words are removed.
